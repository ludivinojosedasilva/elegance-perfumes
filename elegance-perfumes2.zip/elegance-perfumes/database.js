// database.js
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');

async function setup() {
    const db = await open({
        filename: './perfumes.db',
        driver: sqlite3.Database
    });

    await db.exec('PRAGMA foreign_keys = ON;'); // Habilita o suporte a chaves estrangeiras

    await db.exec(`
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            price REAL,
            imageUrl TEXT
        );
    `);

    await db.exec(`
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            subject TEXT,
            message TEXT,
            createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    // --- NOVAS TABELAS DE PEDIDOS ---
    await db.exec(`
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            customer_address TEXT NOT NULL,
            total_amount REAL NOT NULL,
            status TEXT DEFAULT 'PENDENTE',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    `);

    await db.exec(`
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            quantity INTEGER NOT NULL,
            price REAL NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
        );
    `);
    // --- FIM DAS NOVAS TABELAS ---

    const count = await db.get("SELECT COUNT(id) as count FROM products");
    if (count.count === 0) {
        // (código para inserir produtos, sem alterações)
        await db.run("INSERT INTO products (name, description, price, imageUrl) VALUES (?, ?, ?, ?)", "Noir Elegance", "Uma fragrância amadeirada com notas de sândalo, baunilha e pimenta rosa.", 299.90, "https://placehold.co/600x800/EDF2F4/2B2D42?text=ELEGANCE+Noir");
        await db.run("INSERT INTO products (name, description, price, imageUrl) VALUES (?, ?, ?, ?)", "Fleur Royale", "Notas florais de jasmim, rosa e peônia com acabamento baunilhado.", 329.90, "https://placehold.co/600x800/EDF2F4/2B2D42?text=ELEGANCE+Fleur");
        // ... mais produtos ...
        console.log('Banco de dados populado com sucesso!');
    }

    return db;
}

module.exports = setup;