// server.js
const express = require('express');
const setupDatabase = require('./database.js');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

async function main() {
    const db = await setupDatabase();

    // Rota para buscar produtos com paginação
    app.get('/api/products', async (req, res) => {
        const limit = parseInt(req.query.limit) || 3;
        const offset = parseInt(req.query.offset) || 0;

        try {
            const products = await db.all("SELECT * FROM products LIMIT ? OFFSET ?", [limit, offset]);
            const total = await db.get("SELECT COUNT(id) as count FROM products");
            res.json({ products, total: total.count });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: "Erro ao buscar produtos." });
        }
    });
    
    // Rota de contato
    app.post('/api/contact', async (req, res) => {
        const { name, email, subject, message } = req.body;
        if (!name || !email || !message) {
            return res.status(400).json({ message: 'Nome, email e mensagem são obrigatórios.' });
        }
        try {
            await db.run("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)", name, email, subject, message);
            res.status(201).json({ message: 'Mensagem recebida com sucesso! Obrigado pelo contato.' });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: 'Erro ao salvar a mensagem.' });
        }
    });

    // Rota para criar pedidos
    app.post('/api/orders', async (req, res) => {
        const { customerName, customerAddress, cart } = req.body;

        if (!customerName || !customerAddress || !cart || cart.length === 0) {
            return res.status(400).json({ message: 'Dados do pedido inválidos.' });
        }

        try {
            let totalAmount = 0;
            for (const item of cart) {
                const product = await db.get("SELECT price FROM products WHERE id = ?", item.id);
                if (product) {
                    totalAmount += product.price * item.quantity;
                } else {
                    throw new Error(`Produto com ID ${item.id} não encontrado.`);
                }
            }

            await db.run('BEGIN TRANSACTION');

            const result = await db.run(
                "INSERT INTO orders (customer_name, customer_address, total_amount) VALUES (?, ?, ?)",
                customerName,
                customerAddress,
                totalAmount
            );
            const orderId = result.lastID;

            for (const item of cart) {
                await db.run(
                    "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
                    orderId,
                    item.id,
                    item.quantity,
                    item.price
                );
            }
            
            await db.run('COMMIT');

            res.status(201).json({ message: 'Pedido criado com sucesso!', orderId: orderId });

        } catch (error) {
            await db.run('ROLLBACK');
            console.error(error);
            res.status(500).json({ message: 'Erro ao criar o pedido.' });
        }
    });

    // Inicia o servidor
    app.listen(PORT, () => {
        console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    });
}

main();